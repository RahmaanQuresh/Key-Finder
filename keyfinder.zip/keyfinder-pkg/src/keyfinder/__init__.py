"""keyfinder - find leaked secrets in build output and source trees."""
from .scanner import Finding, scan_file, scan_path

__all__ = ["Finding", "scan_file", "scan_path"]
__version__ = "0.1.0"
