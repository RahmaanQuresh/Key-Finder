from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .scanner import scan_path


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="keyfinder",
        description="Find leaked secrets in files and build output. Findings are redacted.",
    )
    ap.add_argument("paths", nargs="*", default=["."], help="files or directories (default: .)")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--exit-zero", action="store_true", help="always exit 0 (report only)")
    ap.add_argument("--version", action="version", version=f"keyfinder {__version__}")
    args = ap.parse_args(argv)

    findings = [f for p in args.paths for f in scan_path(p)]

    if args.json:
        print(json.dumps([f.__dict__ for f in findings], indent=2))
    else:
        for f in findings:
            print(f"{f.path}:{f.line}  {f.rule}  {f.redacted}")
        print(f"\n{len(findings)} potential secret(s) found.", file=sys.stderr)
        if findings:
            print(
                "Rotate/revoke each one first, then remove it from the code and git history.",
                file=sys.stderr,
            )
    return 0 if (args.exit_zero or not findings) else 1
