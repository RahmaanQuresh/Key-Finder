"""Core scanning logic. Secrets are always redacted in results."""
from __future__ import annotations

import fnmatch
import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator

PATTERNS = {
    "AWS access key ID": re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    "GitHub token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"),
    "Slack token": re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b"),
    "Google API key": re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b"),
    "Stripe live key": re.compile(r"\b[sr]k_live_[0-9a-zA-Z]{24,}\b"),
    "Private key block": re.compile(
        r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"
    ),
    "Generic assignment": re.compile(
        r"""(?i)\b(?:api[_-]?key|secret|token|passwd|password)\b\s*[:=]\s*['"]([A-Za-z0-9/+_\-]{16,})['"]"""
    ),
}

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".tox"}
MAX_BYTES = 2_000_000
INLINE_IGNORE = "keyfinder:ignore"
IGNORE_FILE = ".keyfinderignore"
MIN_ENTROPY = 3.5


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    rule: str
    redacted: str


def entropy(s: str) -> float:
    if not s:
        return 0.0
    return -sum((s.count(c) / len(s)) * math.log2(s.count(c) / len(s)) for c in set(s))


def redact(s: str) -> str:
    return s[:4] + "..." + "*" * 6 if len(s) > 8 else "*" * len(s)


def _is_binary(path: str) -> bool:
    with open(path, "rb") as f:
        return b"\0" in f.read(1024)


def scan_file(path: str) -> list[Finding]:
    """Scan one file. Returns redacted findings; never the raw secret."""
    hits: list[Finding] = []
    try:
        if os.path.getsize(path) > MAX_BYTES or _is_binary(path):
            return hits
        with open(path, "r", errors="ignore") as f:
            for n, line in enumerate(f, 1):
                if INLINE_IGNORE in line:
                    continue
                for name, rx in PATTERNS.items():
                    m = rx.search(line)
                    if not m:
                        continue
                    val = m.group(1) if m.groups() else m.group(0)
                    if name == "Generic assignment" and entropy(val) < MIN_ENTROPY:
                        continue  # likely a placeholder
                    hits.append(Finding(path, n, name, redact(val)))
    except OSError:
        pass
    return hits


def load_ignore_patterns(root: str) -> list[str]:
    """Read glob patterns from <root>/.keyfinderignore (one per line, # comments)."""
    p = Path(root) / IGNORE_FILE
    if not p.is_file():
        return []
    lines = p.read_text(errors="ignore").splitlines()
    return [l.strip() for l in lines if l.strip() and not l.lstrip().startswith("#")]


def _ignored(rel_path: str, patterns: Iterable[str]) -> bool:
    rel = rel_path.replace(os.sep, "/")
    base = rel.rsplit("/", 1)[-1]
    return any(fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(base, p) for p in patterns)


def scan_path(target: str, ignore_patterns: Iterable[str] | None = None) -> Iterator[Finding]:
    """Scan a file or directory tree."""
    if os.path.isfile(target):
        yield from scan_file(target)
        return
    patterns = list(ignore_patterns) if ignore_patterns is not None else load_ignore_patterns(target)
    for dirpath, dirs, files in os.walk(target):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fn in files:
            full = os.path.join(dirpath, fn)
            if _ignored(os.path.relpath(full, target), patterns):
                continue
            yield from scan_file(full)
