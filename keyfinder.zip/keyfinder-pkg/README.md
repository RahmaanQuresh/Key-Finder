# keyfinder

Find leaked secrets (API keys, tokens, private keys) in your build output and
source tree **before they ship**. Findings are always redacted, so the report
itself never becomes a second leak. Exits non-zero when something is found, so
CI can block the build.

Scans local files only. No network access, no dependencies.

## Install

```bash
pip install keyfinder          # once published
# or from source
pip install -e .
```

## Usage

```bash
keyfinder ./build              # scan a directory
keyfinder src/app.py .env      # scan specific files
keyfinder . --json             # machine-readable output
keyfinder . --exit-zero        # report only, never fail
```

Example output:

```
build/config.js:12  AWS access key ID  AKIA...******

1 potential secret(s) found.
```

## What it detects

AWS access key IDs, GitHub tokens, Slack tokens, Google API keys, Stripe live
keys, PEM private key blocks, and generic `password/secret/token/api_key = "..."`
assignments (with an entropy check to skip placeholders).

## Suppressing false positives

- Inline: add `keyfinder:ignore` in a comment on the line.
- File-level: create `.keyfinderignore` in the scanned directory, one glob per
  line (`#` for comments):

```
tests/fixtures/*
docs/*.md
```

## CI (GitHub Actions)

```yaml
- run: pip install keyfinder
- run: keyfinder ./build
```

## pre-commit

```yaml
repos:
  - repo: https://github.com/YOUR-USERNAME/keyfinder
    rev: v0.1.0
    hooks:
      - id: keyfinder
```

## If it finds a real secret

1. **Rotate or revoke it first.** Anything that was ever committed or published
   should be treated as compromised.
2. Then remove it from code and git history.

## Limitations

Regex-based and deliberately small. It does not scan git history. For broader
coverage, use it alongside tools like gitleaks or trufflehog.

## Development

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT
