from keyfinder.scanner import entropy, redact, scan_path
from keyfinder.cli import main

# Built by concatenation so this test file doesn't flag itself.
FAKE_AWS = "AKIA" + "IOSFODNN7EXAMPLE"
FAKE_GH = "ghp_" + "a1B2c3D4" * 5


def write(tmp_path, name, text):
    p = tmp_path / name
    p.write_text(text)
    return p


def test_detects_aws_and_github(tmp_path):
    write(tmp_path, "a.env", f"AWS={FAKE_AWS}\nGH={FAKE_GH}\n")
    rules = {f.rule for f in scan_path(str(tmp_path))}
    assert {"AWS access key ID", "GitHub token"} <= rules


def test_output_is_redacted(tmp_path):
    write(tmp_path, "a.env", f"AWS={FAKE_AWS}\n")
    for f in scan_path(str(tmp_path)):
        assert FAKE_AWS not in f.redacted


def test_placeholder_password_ignored(tmp_path):
    write(tmp_path, "c.py", 'password = "aaaaaaaaaaaaaaaaaaaa"\n')
    assert list(scan_path(str(tmp_path))) == []


def test_high_entropy_password_flagged(tmp_path):
    write(tmp_path, "c.py", 'password = "xK9fQ2mZ7vL1pR8sT3wY"\n')
    assert len(list(scan_path(str(tmp_path)))) == 1


def test_inline_ignore(tmp_path):
    write(tmp_path, "a.txt", f"{FAKE_AWS}  # keyfinder:ignore\n")
    assert list(scan_path(str(tmp_path))) == []


def test_ignore_file(tmp_path):
    write(tmp_path, "fixtures.txt", FAKE_AWS + "\n")
    write(tmp_path, ".keyfinderignore", "# comment\nfixtures.txt\n")
    assert list(scan_path(str(tmp_path))) == []


def test_skips_binary(tmp_path):
    (tmp_path / "b.bin").write_bytes(b"\0\0" + FAKE_AWS.encode())
    assert list(scan_path(str(tmp_path))) == []


def test_exit_codes(tmp_path):
    clean = write(tmp_path, "ok.txt", "nothing here\n")
    dirty = write(tmp_path, "bad.txt", FAKE_AWS + "\n")
    assert main([str(clean)]) == 0
    assert main([str(dirty)]) == 1
    assert main([str(dirty), "--exit-zero"]) == 0


def test_helpers():
    assert entropy("aaaa") == 0
    assert redact("short") == "*****"
    assert redact("AKIAEXAMPLE1234567").startswith("AKIA")
